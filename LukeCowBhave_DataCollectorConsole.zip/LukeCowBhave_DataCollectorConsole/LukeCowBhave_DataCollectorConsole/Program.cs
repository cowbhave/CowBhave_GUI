﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using NetMQ;
using NetMQ.Sockets;
using System.IO;
using System.Timers;
using System.Net.Mail;

namespace LukeCowBhave_DataCollectorConsole
{
    class Program
    {
        static int MaxTagNoN = 101;
        static int MaxStationNoN = 31;

        static string RuuviDataLine;
        static string[] RuuviDataTag = new string[MaxTagNoN];
        static string ParamFileName = "LukeCowBhave_DataCollector_Param.txt";
        static int RuuviDataSavePeriod = 10;//sec
        static string RuuviDataSaveFolderPath;
        static string RuuviDataSaveFileNameTagPart1, RuuviDataSaveFileNameTagPart2;
        private static volatile bool RuuviDataThreadRun = true;
        static int InactiveTagAndStationPeriod = 3;//sec

        static readonly object RuuviDataSaveTimerLocker = new object();

        static int RaspStationN;
        static string[] RaspStationIP = new string[MaxStationNoN];
        static DateTime[] StationNoActiveInd_TimeLastSeen = new DateTime[MaxStationNoN];
        //static int ComputerTimeCorrection;

        string[] TagMACList = new string[MaxTagNoN];
        static bool[] TagNoInd = new bool[MaxTagNoN];
        static bool[] StationNoInd = new bool[MaxStationNoN];

        static bool[] TagNoActiveInd = new bool[MaxTagNoN];
        static DateTime[] TagNoActiveInd_TimeLastSeen = new DateTime[MaxTagNoN];
        string[] TagMACActiveInd = new string[MaxTagNoN];
        static bool[] StationNoActiveInd = new bool[MaxStationNoN];
        static double SentRecievedDiffAverage = 0, SentRecievedDiffAverage_prev = 0;

        static bool MailSent = false;

        static void Main(string[] args)
        {
            LoadParam();

            RuuviDataTag = new string[MaxTagNoN];

            System.Timers.Timer RuuviDataSaveTimer = new System.Timers.Timer(RuuviDataSavePeriod * 1000);
            RuuviDataSaveTimer.Elapsed += new ElapsedEventHandler(RuuviDataSaveTimerFunction);
            //RuuviDataSaveTimer.AutoReset = false;
            RuuviDataSaveTimer.Start();

            RuuviDataSaveFileNameTagPart1 = "RuuviData_Tag";

            var RuuviDataThread = new Thread(RuuviDataRecieve);
            RuuviDataThread.IsBackground = true;
            RuuviDataThread.Start();

            //start data presentation timer
            System.Timers.Timer RuuviDataPresentationTimer = new System.Timers.Timer(60 * 1000);
            RuuviDataPresentationTimer.Elapsed += new ElapsedEventHandler(RuuviDataPresentationTimerFunction);
            //RuuviDataPresentationTimer.AutoReset = false;
            RuuviDataPresentationTimer.Start();

            while (true)
            {

            }/**/
        }

        private static void RuuviDataRecieve()
        {
            var subSocket1 = new SubscriberSocket();
            var subSocket2 = new SubscriberSocket();
            var subSocket3 = new SubscriberSocket();
            var subSocket4 = new SubscriberSocket();
            var subSocket5 = new SubscriberSocket();
            var subSocket6 = new SubscriberSocket();
            var subSocket7 = new SubscriberSocket();
            var subSocket8 = new SubscriberSocket();
            var subSocket9 = new SubscriberSocket();
            var subSocket10 = new SubscriberSocket();
            var subSocket11 = new SubscriberSocket();
            var subSocket12 = new SubscriberSocket();
            DateTime TimeStamp, TimeStamp_prev;
            TimeStamp = DateTime.Now;
            TimeStamp_prev = TimeStamp;
            TimeSpan NormalWaitingTime = TimeSpan.FromMilliseconds(10);

            if (RaspStationN > 0)
            {
                subSocket1.Options.ReceiveHighWatermark = 1000;
                subSocket1.Connect("tcp://" + RaspStationIP[0]);
                subSocket1.Subscribe("");
            }
            if (RaspStationN > 1)
            {
                subSocket2.Options.ReceiveHighWatermark = 1000;
                subSocket2.Connect("tcp://" + RaspStationIP[1]);
                subSocket2.Subscribe("");
            }
            if (RaspStationN > 2)
            {
                subSocket3.Options.ReceiveHighWatermark = 1000;
                subSocket3.Connect("tcp://" + RaspStationIP[2]);
                subSocket3.Subscribe("");
            }
            if (RaspStationN > 3)
            {
                subSocket4.Options.ReceiveHighWatermark = 1000;
                subSocket4.Connect("tcp://" + RaspStationIP[3]);
                subSocket4.Subscribe("");
            }
            if (RaspStationN > 4)
            {
                subSocket5.Options.ReceiveHighWatermark = 1000;
                subSocket5.Connect("tcp://" + RaspStationIP[4]);
                subSocket5.Subscribe("");
            }
            if (RaspStationN > 5)
            {
                subSocket6.Options.ReceiveHighWatermark = 1000;
                subSocket6.Connect("tcp://" + RaspStationIP[5]);
                subSocket6.Subscribe("");
            }
            if (RaspStationN > 6)
            {
                subSocket7.Options.ReceiveHighWatermark = 1000;
                subSocket7.Connect("tcp://" + RaspStationIP[6]);
                subSocket7.Subscribe("");
            }
            if (RaspStationN > 7)
            {
                subSocket8.Options.ReceiveHighWatermark = 1000;
                subSocket8.Connect("tcp://" + RaspStationIP[7]);
                subSocket8.Subscribe("");
            }
            if (RaspStationN > 8)
            {
                subSocket9.Options.ReceiveHighWatermark = 1000;
                subSocket9.Connect("tcp://" + RaspStationIP[8]);
                subSocket9.Subscribe("");
            }
            if (RaspStationN > 9)
            {
                subSocket10.Options.ReceiveHighWatermark = 1000;
                subSocket10.Connect("tcp://" + RaspStationIP[9]);
                subSocket10.Subscribe("");
            }
            if (RaspStationN > 10)
            {
                subSocket11.Options.ReceiveHighWatermark = 1000;
                subSocket11.Connect("tcp://" + RaspStationIP[10]);
                subSocket11.Subscribe("");
            }
            if (RaspStationN > 11)
            {
                subSocket12.Options.ReceiveHighWatermark = 1000;
                subSocket12.Connect("tcp://" + RaspStationIP[11]);
                subSocket12.Subscribe("");
            }

            while (RuuviDataThreadRun)
            {
                TimeStamp = DateTime.Now;
                try
                {
                    if (RaspStationN > 0)
                    {
                        subSocket1.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                        }
                    }
                    if (RaspStationN > 1)
                    {
                        subSocket2.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                        }
                    }
                    if (RaspStationN > 2)
                    {
                        subSocket3.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                        }
                    }
                    if (RaspStationN > 3)
                    {
                        subSocket4.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                        }
                    }
                    if (RaspStationN > 4)
                    {
                        subSocket5.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                            //Console.WriteLine(RuuviDataLine);
                            //Console.WriteLine("St 5 " + Convert.ToString(g++));
                        }
                    }
                    if (RaspStationN > 5)
                    {
                        subSocket6.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                        }
                    }
                    if (RaspStationN > 6)
                    {
                        subSocket7.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                        }
                    }
                    if (RaspStationN > 7)
                    {
                        subSocket8.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                        }
                    }
                    if (RaspStationN > 8)
                    {
                        subSocket9.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                        }
                    }
                    if (RaspStationN > 9)
                    {
                        subSocket10.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                        }
                    }
                    if (RaspStationN > 10)
                    {
                        subSocket11.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                        }
                    }
                    if (RaspStationN > 11)
                    {
                        subSocket12.TryReceiveFrameString(NormalWaitingTime, out RuuviDataLine);
                        if (!string.IsNullOrEmpty(RuuviDataLine))
                        {
                            UpdateActiveTagStationData(RuuviDataLine);
                        }
                    }
                }
                catch (InvalidCastException e)
                {
                }
            }
        }

        private static void LoadParam()
        {
            int i;
            //Parameters file
            if (File.Exists(ParamFileName))
            {
                StreamReader sr = new StreamReader(ParamFileName);
                string line;
                string[] d;

                //DataSaveFolderPath
                line = sr.ReadLine();
                RuuviDataSaveFolderPath = line.Substring(line.IndexOf(" ") + 1, line.Length - line.IndexOf(" ") - 1);
                if (RuuviDataSaveFolderPath[RuuviDataSaveFolderPath.Length - 1] != '\"')
                    RuuviDataSaveFolderPath += "\\";

                //RaspStationN
                line = sr.ReadLine();
                d = line.Split(' ');
                RaspStationN = Convert.ToInt32(d[1]);

                for (i = 0; i < MaxStationNoN; i++) StationNoInd[i] = false;

                //RaspStation list
                for (i = 0; i < RaspStationN; i++)
                {
                    line = sr.ReadLine();
                    d = line.Split(' ');
                    RaspStationIP[i] = d[2];
                    StationNoInd[Convert.ToInt32(d[1])] = true;
                }

                for (i = 0; i < MaxTagNoN; i++) TagNoInd[i] = false;

                line = sr.ReadLine();
                d = line.Split(' ');
                for (i = 1; i < d.Length; i++)
                {
                    TagNoInd[Convert.ToInt32(d[i])] = true;
                }

                sr.Close();
            }
            else
            {//should be created the parameter file with some default values
                Console.WriteLine("Create parameters file '" + ParamFileName + "'");
            }
        }

        private static void RuuviDataSaveTimerFunction(object source, ElapsedEventArgs e)
        {
            int TagNo;
            string CurrentFolder;

            Monitor.Enter(RuuviDataSaveTimerLocker);
            for (TagNo = 0; TagNo < MaxTagNoN; TagNo++)
            {
                if (TagNoActiveInd[TagNo])
                {
                    //RuuviDataSaveFileNameTagPart2 = "_" + DateTime.Now.ToString("yyyy-MM-dd-HH") + ".csv";
                    RuuviDataSaveFileNameTagPart2 = "_" + DateTime.Now.ToString("yyyy-MM-dd") + ".csv";
                    CurrentFolder = DateTime.Now.ToString("yyyy-MM-dd") + "/";
                    if (!Directory.Exists(RuuviDataSaveFolderPath + CurrentFolder))
                        Directory.CreateDirectory(RuuviDataSaveFolderPath + CurrentFolder);
                    File.AppendAllText(RuuviDataSaveFolderPath + CurrentFolder +
                        RuuviDataSaveFileNameTagPart1 + Convert.ToString(TagNo) + RuuviDataSaveFileNameTagPart2, RuuviDataTag[TagNo]);
                    RuuviDataTag[TagNo] = "";
                }
            }
            Monitor.Exit(RuuviDataSaveTimerLocker);
        }

        private static void UpdateActiveTagStationData(string s)
        {
            int StationNo, TagNo;
            string Message;
            string[] d;
            // NumberFormatInfo provider = new NumberFormatInfo();
            // provider.NumberDecimalSeparator = ".";
            int k_END, k;
            DateTime TimeStamp = DateTime.Now;
            //TimeStamp = TimeStamp.AddSeconds(ComputerTimeCorrection);
            DateTime RecievedTimeStamp;

            //k_END = s.IndexOf("ENDMES");
            //s = s.Substring(0, k_END);

            k_END = s.IndexOf("END");
            k = 0;
            while (k_END != -1)
            {
                if (k_END - k > 70)
                {
                    Message = s.Substring(k, k_END - k);
                    //Console.WriteLine(Message);
                    d = Message.Split(',');
                    if (d.Length >= 19)
                    {
                        StationNo = Convert.ToInt32(d[0]);
                        RecievedTimeStamp = Convert.ToDateTime(d[1]);
                        if (d[2] == "" || d[2].Length >= 17)//tag was not found in the MAC list
                        {
                            TagNo=0;
                        }
                        else
                            TagNo = Convert.ToInt32(d[2]);

                        //RuuviData += w + "\r\n";
                        //Message += TimeStamp.ToString("yyyy,MM,dd,HH,mm,ss,fff");
                        RuuviDataTag[TagNo] += Message + "\r\n";

                        //update the lists of active stations and tags
                        TagNoActiveInd_TimeLastSeen[TagNo] = TimeStamp;
                        TagNoActiveInd[TagNo] = true;
                        StationNoActiveInd_TimeLastSeen[StationNo] = TimeStamp;
                        StationNoActiveInd[StationNo] = true;

                        SentRecievedDiffAverage = 0.9 * SentRecievedDiffAverage + 0.1 * (TimeStamp - RecievedTimeStamp).TotalSeconds;
                    }
                }

                k = k_END + 5;
                k_END = s.IndexOf("END", k);
            }
        }

        private static void RuuviDataPresentationTimerFunction(object source, ElapsedEventArgs e)
        {
            int TagNo, StationNo, n;
            DateTime TimeStamp = DateTime.Now;
            Monitor.Enter(RuuviDataSaveTimerLocker);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss"));
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Lag " + Convert.ToString(Math.Round(SentRecievedDiffAverage)));

            //tag status
            TagNoActiveInd[0] = false;
            for (TagNo = 1; TagNo < MaxTagNoN; TagNo++)//search for a disappering tag
            {
                if (TagNoActiveInd[TagNo])
                    if ((TimeStamp - TagNoActiveInd_TimeLastSeen[TagNo]).TotalSeconds > InactiveTagAndStationPeriod)
                    {
                        TagNoActiveInd[TagNo] = false;
                    }
                    /*else
                    {
                        Console.Write(Convert.ToString(TagNo) + " ");
                        n++;
                    }*/
            }
            Console.WriteLine("Active tags: ");
            n = 0;
            for (TagNo = 1; TagNo < MaxTagNoN; TagNo++)//search for a disappering tag
            {
                if (TagNoInd[TagNo] && TagNoActiveInd[TagNo])
                {
                    Console.Write(Convert.ToString(TagNo) + " ");
                    n++;
                }
            }
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(", totally " + Convert.ToString(n) + " tags");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Inactive tags: ");
            n = 0;
            for (TagNo = 1; TagNo < MaxTagNoN; TagNo++)//search for a disappering tag
            {
                if (TagNoInd[TagNo] && !TagNoActiveInd[TagNo])
                {
                    Console.Write(Convert.ToString(TagNo) + " ");
                    n++;
                }
            }
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(", totally " + Convert.ToString(n) + " tags");
            Console.ForegroundColor = ConsoleColor.White;


            for (StationNo = 1; StationNo < MaxStationNoN; StationNo++)//search for a disappering Rasp station
            {
                if (StationNoActiveInd[StationNo])
                    if ((TimeStamp - StationNoActiveInd_TimeLastSeen[StationNo]).TotalSeconds > InactiveTagAndStationPeriod)
                    {
                        StationNoActiveInd[StationNo] = false;
                    }
                    /*else
                    {
                        Console.Write(Convert.ToString(StationNo) + " ");
                        n++;
                    }*/
            }

            n = 0;
            Console.Write("Active stations: ");
            for (StationNo = 1; StationNo < MaxStationNoN; StationNo++)//search for a disappering Rasp station
            {
                if (StationNoInd[StationNo] && StationNoActiveInd[StationNo])
                    {
                        n++;
                        Console.Write(Convert.ToString(StationNo) + " ");
                    }
            }          
            //StationNoInd
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(", totally " + Convert.ToString(n) + " stations");
            Console.ForegroundColor = ConsoleColor.White;

            n = 0;
            Console.Write("Inactive stations: ");
            for (StationNo = 1; StationNo < MaxStationNoN; StationNo++)//search for a disappering Rasp station
            {
                if (StationNoInd[StationNo] && !StationNoActiveInd[StationNo])
                    {
                        n++;
                        Console.Write(Convert.ToString(StationNo) + " ");
                    }
            }
            //StationNoInd
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine(", totally " + Convert.ToString(n) + " stations");
            Console.ForegroundColor = ConsoleColor.White;


            if (n==0 && !MailSent)
            {
                MailMessage message = new MailMessage("victor.bloch18@gmail.com", "victor.bloch@luke.fi");
                message.Subject = "No data";
                message.Body = @"";
                SmtpClient client = new SmtpClient();
                client.Credentials = new System.Net.NetworkCredential("victor.bloch18@gmail.com", "Vvv17129");
                client.Port = 587;
                client.Host = "smtp.gmail.com";
                client.EnableSsl = true;
                client.UseDefaultCredentials = true;
                try
                {
                    client.Send(message);
                }
                catch { }

                MailSent = true;
            }

            Monitor.Exit(RuuviDataSaveTimerLocker);
        }
    }
}
